"""
utils.py - Utility Functions for AI-Integrated Science Curriculum Project
Configures publication-quality plotting styles, directory management,
data serialization (CSV and Excel), and reproducible random seeds.
"""

import os
import random
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib as mpl

# Set fixed random seed for full reproducibility
RANDOM_SEED = 42


def set_seed(seed=RANDOM_SEED):
    """Set random seed across Python random and NumPy."""
    random.seed(seed)
    np.random.seed(seed)
    os.environ['PYTHONHASHSEED'] = str(seed)


def setup_publication_plot_style():
    """
    Configure global matplotlib parameters according to strict publication guidelines:
    - High DPI (800 for raster, vector-ready)
    - Times New Roman font (with serif fallback)
    - Bold font weights, size 18
    - Grid lines removed
    - High-contrast publication palette
    - Professional axis borders (spines)
    """
    plt.rcParams.update({
        "figure.figsize": (11, 7),
        "figure.dpi": 800,
        "savefig.dpi": 800,
        "font.family": "serif",
        "font.serif": ["Times New Roman", "DejaVu Serif", "Times", "Liberation Serif"],
        "font.size": 18,
        "font.weight": "bold",
        "axes.labelweight": "bold",
        "axes.titleweight": "bold",
        "axes.titlesize": 20,
        "axes.labelsize": 18,
        "xtick.labelsize": 15,
        "ytick.labelsize": 15,
        "legend.fontsize": 15,
        "legend.title_fontsize": 16,
        "legend.frameon": True,
        "legend.facecolor": "white",
        "legend.edgecolor": "#333333",
        "legend.framealpha": 0.95,
        "axes.grid": False,
        "axes.edgecolor": "#111111",
        "axes.linewidth": 1.6,
        "xtick.major.width": 1.4,
        "ytick.major.width": 1.4,
        "xtick.major.size": 6,
        "ytick.major.size": 6,
        "figure.autolayout": True,
        "lines.linewidth": 2.2,
        "patch.linewidth": 1.4
    })


def export_table(df: pd.DataFrame, table_id: str, title: str, output_dir: str):
    """
    Export DataFrame exclusively to formatted Excel (.xlsx) file in the tables section.
    """
    os.makedirs(output_dir, exist_ok=True)
    xlsx_path = os.path.join(output_dir, f"{table_id}.xlsx")

    # Export to Excel with professional publication formatting
    try:
        with pd.ExcelWriter(xlsx_path, engine="openpyxl") as writer:
            df.to_excel(writer, sheet_name=table_id[:31], index=False)
            workbook = writer.book
            worksheet = writer.sheets[table_id[:31]]

            # Format header
            from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
            header_font = Font(name="Times New Roman", size=11, bold=True, color="FFFFFF")
            header_fill = PatternFill(start_color="1F4E79", end_color="1F4E79", fill_type="solid")
            thin_border = Border(
                left=Side(style="thin", color="D3D3D3"),
                right=Side(style="thin", color="D3D3D3"),
                top=Side(style="thin", color="D3D3D3"),
                bottom=Side(style="thin", color="D3D3D3")
            )
            for cell in worksheet[1]:
                cell.font = header_font
                cell.fill = header_fill
                cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)

            # Auto-fit column widths
            for col in worksheet.columns:
                max_len = 0
                col_letter = col[0].column_letter
                for cell in col:
                    cell.border = thin_border
                    val_str = str(cell.value or "")
                    if len(val_str) > max_len:
                        max_len = len(val_str)
                worksheet.column_dimensions[col_letter].width = min(max(max_len + 3, 12), 45)
    except Exception as e:
        print(f"[Warning] Excel export failed for {table_id}: {e}")

    return xlsx_path


def save_publication_figure(fig, fig_id: str, output_dir: str, dpi=800):
    """
    Save figure exclusively in high-resolution PNG format (800 DPI).
    """
    os.makedirs(output_dir, exist_ok=True)
    png_path = os.path.join(output_dir, f"{fig_id}.png")

    fig.savefig(png_path, dpi=dpi, bbox_inches="tight", format="png")
    plt.close(fig)

    return png_path

