"""
visualization.py - Publication-Quality Figure Generation Module
Generates all 8 publication figures according to strict academic journal standards:
- Figure 1: Theoretical foundation diagram
- Figure 2: Traditional science curriculum before AI integration
- Figure 3: Proposed AI-integrated science curriculum framework (P1-P5, activities, assessment, outcomes)
- Figure 4: Sequential mixed-methods research design
- Figure 5: Expert validation workflow
- Figure 6: Student implementation workflow
- Figure 7: Pre-test versus post-test outcome comparison (grouped bar chart with error bars)
- Figure 8: Mixed-methods integrated findings visualization

Configured at 800 DPI (high-resolution raster) and saved simultaneously as PNG, TIFF, and EPS.
"""

import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as patches
from src.utils import setup_publication_plot_style, save_publication_figure


# Set publication style globally
setup_publication_plot_style()


# ==============================================================================
# FIGURE 1: THEORETICAL FOUNDATION DIAGRAM
# ==============================================================================

def generate_figure_1(output_dir: str):
    """
    Figure 1: Theoretical Foundation Diagram
    Grounded in Constructivism, Constructionism & Computational Thinking,
    Social Constructivism, TPACK, and Digital Scientific Literacy,
    converging into the AI-Integrated Science Curriculum Framework and Target Outcomes.
    """
    fig, ax = plt.subplots(figsize=(11, 7), dpi=800)
    ax.set_xlim(0, 100)
    ax.set_ylim(0, 100)
    ax.axis("off")

    # Header Title
    ax.text(50, 95, "Figure 1: Theoretical Foundations of AI-Integrated Science Curriculum",
            ha="center", va="center", fontsize=18, fontweight="bold", color="#111111")

    # Level 1: Foundational Learning Theories (Top 4 Boxes)
    theories = [
        {"x": 12, "y": 78, "w": 22, "h": 12, "title": "Constructivism\n(Piaget, 1973)", "sub": "Active knowledge building;\nexperiential inquiry"},
        {"x": 38, "y": 78, "w": 24, "h": 12, "title": "Constructionism & CT\n(Papert, 1980; Wing, 2006)", "sub": "Computing as thinking tool;\ncomputational artifacts"},
        {"x": 66, "y": 78, "w": 22, "h": 12, "title": "Social Constructivism\n(Vygotsky, 1978)", "sub": "Collaborative agency;\npeer scaffolding in STEM"},
    ]

    for th in theories:
        rect = patches.FancyBboxPatch((th["x"] - th["w"]/2, th["y"] - th["h"]/2), th["w"], th["h"],
                                      boxstyle="round,pad=0.8,rounding_size=1.5",
                                      facecolor="#EBF1F5", edgecolor="#1F4E79", linewidth=2.0)
        ax.add_patch(rect)
        ax.text(th["x"], th["y"] + 2.0, th["title"], ha="center", va="center", fontsize=11, fontweight="bold", color="#1F4E79")
        ax.text(th["x"], th["y"] - 2.8, th["sub"], ha="center", va="center", fontsize=9.5, fontweight="normal", color="#333333")

    # Level 2: Intersecting Pedagogical & Technological Models (2 Boxes)
    sub_theories = [
        {"x": 28, "y": 55, "w": 34, "h": 12, "title": "TPACK Framework (Mishra & Koehler, 2006)", "sub": "Integration of Technological, Pedagogical,\nand Scientific Content Knowledge"},
        {"x": 72, "y": 55, "w": 34, "h": 12, "title": "Digital Scientific Literacy (OECD, 2023)", "sub": "Critical data evaluation, bias detection,\nand empirical digital communication"}
    ]

    for st in sub_theories:
        rect = patches.FancyBboxPatch((st["x"] - st["w"]/2, st["y"] - st["h"]/2), st["w"], st["h"],
                                      boxstyle="round,pad=0.8,rounding_size=1.5",
                                      facecolor="#D9E1F2", edgecolor="#2F5597", linewidth=2.0)
        ax.add_patch(rect)
        ax.text(st["x"], st["y"] + 2.0, st["title"], ha="center", va="center", fontsize=11, fontweight="bold", color="#2F5597")
        ax.text(st["x"], st["y"] - 2.8, st["sub"], ha="center", va="center", fontsize=9.5, fontweight="normal", color="#222222")

    # Connecting Arrows from Level 1 to Level 2
    arrow_props = dict(facecolor="#1F4E79", edgecolor="#1F4E79", width=1.5, headwidth=6, headlength=7, shrink=0.08)
    ax.annotate("", xy=(28, 62), xytext=(18, 71), arrowprops=arrow_props)
    ax.annotate("", xy=(38, 62), xytext=(40, 71), arrowprops=arrow_props)
    ax.annotate("", xy=(70, 62), xytext=(72, 71), arrowprops=arrow_props)

    # Level 3: The Synthesized Curriculum Framework (Center Box)
    cf_rect = patches.FancyBboxPatch((15, 26), 70, 16, boxstyle="round,pad=1.0,rounding_size=2.0",
                                     facecolor="#2F5597", edgecolor="#1B365D", linewidth=2.5)
    ax.add_patch(cf_rect)
    ax.text(50, 37.5, "AI-Integrated Science Curriculum Design Framework",
            ha="center", va="center", fontsize=14, fontweight="bold", color="#FFFFFF")
    ax.text(50, 31.0, "Core Principles: P1 Stakeholder Objectives | P2 Scaffolded Code-Light | P3 Authentic Datasets\nP4 Critical AI Evaluation | P5 Identity, Collaboration & Community",
            ha="center", va="center", fontsize=10.5, fontweight="bold", color="#FFF2CC")

    # Arrows to Level 3
    ax.annotate("", xy=(40, 43), xytext=(32, 48), arrowprops=arrow_props)
    ax.annotate("", xy=(60, 43), xytext=(68, 48), arrowprops=arrow_props)

    # Level 4: Target Learning Outcomes (Bottom 3 Boxes)
    outcomes = [
        {"x": 20, "y": 10, "w": 28, "h": 9.5, "title": "Computational Thinking", "sub": "Decomposition, Pattern Matching,\nAbstraction, Algorithm Design"},
        {"x": 50, "y": 10, "w": 28, "h": 9.5, "title": "Digital Scientific Literacy", "sub": "Data Bias Auditing, Empirical Reasoning,\nCross-Verification Heuristics"},
        {"x": 80, "y": 10, "w": 28, "h": 9.5, "title": "AI Knowledge & Affect", "sub": "Machine Learning Literacy, Self-Efficacy,\nBelonging & Responsible AI Stance"}
    ]

    for oc in outcomes:
        rect = patches.FancyBboxPatch((oc["x"] - oc["w"]/2, oc["y"] - oc["h"]/2), oc["w"], oc["h"],
                                      boxstyle="round,pad=0.6,rounding_size=1.2",
                                      facecolor="#C6E0B4", edgecolor="#385723", linewidth=2.0)
        ax.add_patch(rect)
        ax.text(oc["x"], oc["y"] + 1.8, oc["title"], ha="center", va="center", fontsize=11, fontweight="bold", color="#385723")
        ax.text(oc["x"], oc["y"] - 2.0, oc["sub"], ha="center", va="center", fontsize=8.5, fontweight="bold", color="#1B365D")

    # Arrows from Framework to Outcomes
    arrow_out_props = dict(facecolor="#385723", edgecolor="#385723", width=1.8, headwidth=6, headlength=7, shrink=0.08)
    ax.annotate("", xy=(22, 16), xytext=(35, 25), arrowprops=arrow_out_props)
    ax.annotate("", xy=(50, 16), xytext=(50, 25), arrowprops=arrow_out_props)
    ax.annotate("", xy=(78, 16), xytext=(65, 25), arrowprops=arrow_out_props)

    return save_publication_figure(fig, "Figure_1_Theoretical_Foundations", output_dir)


# ==============================================================================
# FIGURE 2: TRADITIONAL SCIENCE CURRICULUM BEFORE AI INTEGRATION
# ==============================================================================

def generate_figure_2(output_dir: str):
    """
    Figure 2: Traditional Science Curriculum Before AI Integration
    Visualizes conventional pedagogical flow and instructional limitations.
    """
    fig, ax = plt.subplots(figsize=(11, 7), dpi=800)
    ax.set_xlim(0, 100)
    ax.set_ylim(0, 100)
    ax.axis("off")

    ax.text(50, 95, "Figure 2: Conventional Science Curriculum Architecture (Pre-AI)",
            ha="center", va="center", fontsize=18, fontweight="bold", color="#111111")

    # Linear Traditional Stages
    stages = [
        {"x": 15, "y": 68, "title": "1. Didactic Lecture", "desc": "Teacher-dominated delivery\nof static textbook facts\nand scientific laws."},
        {"x": 38, "y": 68, "title": "2. Cookbook Labs", "desc": "Step-by-step procedures\nwith pre-determined\nexperimental outcomes."},
        {"x": 62, "y": 68, "title": "3. Manual Graphing", "desc": "Hand-drawn plots on paper\nor isolated calculators;\nlacks algorithmic modeling."},
        {"x": 85, "y": 68, "title": "4. Rote Assessment", "desc": "Standardized recall tests;\nfact-retention devoid of\ncomputational thinking."}
    ]

    for s in stages:
        rect = patches.FancyBboxPatch((s["x"] - 10, s["y"] - 10), 20, 20,
                                      boxstyle="round,pad=0.8,rounding_size=1.5",
                                      facecolor="#F2DCDB", edgecolor="#C00000", linewidth=2.0)
        ax.add_patch(rect)
        ax.text(s["x"], s["y"] + 4.5, s["title"], ha="center", va="center", fontsize=12, fontweight="bold", color="#C00000")
        ax.text(s["x"], s["y"] - 3.0, s["desc"], ha="center", va="center", fontsize=9.5, fontweight="normal", color="#333333")

    # Linear Connecting Arrows
    arrow_props = dict(facecolor="#C00000", edgecolor="#C00000", width=2.0, headwidth=7, headlength=8, shrink=0.1)
    ax.annotate("", xy=(27, 68), xytext=(24, 68), arrowprops=arrow_props)
    ax.annotate("", xy=(51, 68), xytext=(47, 68), arrowprops=arrow_props)
    ax.annotate("", xy=(74, 68), xytext=(71, 68), arrowprops=arrow_props)

    # Deficits / Limitations Box (Lower Half)
    deficits_rect = patches.FancyBboxPatch((8, 14), 84, 34, boxstyle="round,pad=1.0,rounding_size=2.0",
                                           facecolor="#FFF2F2", edgecolor="#800000", linewidth=2.2, linestyle="--")
    ax.add_patch(deficits_rect)
    ax.text(50, 42, "Structural Deficits & Pedagogical Barriers of the Conventional Model",
            ha="center", va="center", fontsize=13.5, fontweight="bold", color="#800000")

    deficit_points = [
        "• Absence of Computational Thinking: Zero exposure to problem decomposition, pattern recognition, or algorithmic logic.",
        "• Epistemic Passivity Toward AI: Students either view AI as an omniscient oracle or fall victim to undetected hallucinations.",
        "• Unauthentic Data Experience: Synthetic textbook exercises fail to prepare students for noisy, empirical scientific datasets.",
        "• Coding Intimidation & Inequity: Abstract command-line programming isolates novices, creating severe gender and identity gaps."
    ]

    y_pos = 34
    for pt in deficit_points:
        ax.text(12, y_pos, pt, ha="left", va="center", fontsize=10.5, fontweight="bold", color="#4D0000")
        y_pos -= 6.5

    return save_publication_figure(fig, "Figure_2_Conventional_Curriculum", output_dir)


# ==============================================================================
# FIGURE 3: PROPOSED AI-INTEGRATED CURRICULUM FRAMEWORK
# ==============================================================================

def generate_figure_3(output_dir: str):
    """
    Figure 3: Proposed AI-Integrated Science Curriculum Framework
    Illustrates P1-P5 Principles, Learning Activities, Assessment, and Outcomes.
    """
    fig, ax = plt.subplots(figsize=(11, 7), dpi=800)
    ax.set_xlim(0, 100)
    ax.set_ylim(0, 100)
    ax.axis("off")

    ax.text(50, 96, "Figure 3: AI-Integrated Science Curriculum Design Framework",
            ha="center", va="center", fontsize=18, fontweight="bold", color="#111111")

    # Section 1: The 5 Core Principles (Top Layer)
    p_boxes = [
        {"x": 10, "title": "P1: Stakeholder\nObjectives", "sub": "Teacher-expert-\nstudent goals"},
        {"x": 30, "title": "P2: Scaffolded\nCode-Light", "sub": "Visual widgets to\nmodular notebooks"},
        {"x": 50, "title": "P3: Authentic\nDatasets", "sub": "Greenhouse strawberry\ncomputer vision"},
        {"x": 70, "title": "P4: Critical AI\nEvaluation", "sub": "Hallucination audits &\ncross-verification"},
        {"x": 90, "title": "P5: Identity &\nCommunity", "sub": "Inquiry squads &\npeer agency"}
    ]

    for p in p_boxes:
        rect = patches.FancyBboxPatch((p["x"] - 9, 74), 18, 15,
                                      boxstyle="round,pad=0.6,rounding_size=1.2",
                                      facecolor="#1F4E79", edgecolor="#0D233A", linewidth=2.0)
        ax.add_patch(rect)
        ax.text(p["x"], 83.5, p["title"], ha="center", va="center", fontsize=10.5, fontweight="bold", color="#FFFFFF")
        ax.text(p["x"], 78.0, p["sub"], ha="center", va="center", fontsize=8.5, fontweight="bold", color="#FFF2CC")

    # Arrow Down to Activities
    arrow_down = dict(facecolor="#1F4E79", edgecolor="#1F4E79", width=2.0, headwidth=7, headlength=7, shrink=0.1)
    ax.annotate("", xy=(50, 68), xytext=(50, 73), arrowprops=arrow_down)

    # Section 2: AI-Supported Learning Activities (Middle Layer)
    act_rect = patches.FancyBboxPatch((4, 43), 92, 23, boxstyle="round,pad=0.8,rounding_size=1.5",
                                      facecolor="#D9E1F2", edgecolor="#2F5597", linewidth=2.2)
    ax.add_patch(act_rect)
    ax.text(50, 62.5, "AI-Supported Scientific Inquiry Activities (Weeks 1 to 6)",
            ha="center", va="center", fontsize=13.5, fontweight="bold", color="#2F5597")

    act_items = [
        "• Weeks 1-2: Foundations of AI & Problem Decomposition | Visual block models, training vs test sets, classification basics.",
        "• Weeks 3-4: Empirical Botanical Inquiry | Strawberry ripeness computer vision, RGB histogram thresholding, code-light notebooks.",
        "• Weeks 5-6: Epistemic Auditing & Collaborative Synthesis | LLM prompt engineering, hallucination auditing, final squad defense."
    ]
    y_act = 55.5
    for act in act_items:
        ax.text(6, y_act, act, ha="left", va="center", fontsize=9.8, fontweight="bold", color="#1B365D")
        y_act -= 5.5

    # Section 3: Assessment & Outcomes (Bottom Dual-Pillar Layer)
    # Left Pillar: Multi-Tiered Assessment
    ass_rect = patches.FancyBboxPatch((4, 10), 44, 28, boxstyle="round,pad=0.8,rounding_size=1.5",
                                      facecolor="#FCE4D6", edgecolor="#C65911", linewidth=2.0)
    ax.add_patch(ass_rect)
    ax.text(26, 33.5, "Authentic Formative Assessment", ha="center", va="center", fontsize=12.5, fontweight="bold", color="#C65911")
    ass_text = (
        "• 4-Tier CT Decomposition Rubrics\n"
        "• Pre/Post Conceptual Diagnostics\n"
        "• Reciprocal Peer Verification Checklists\n"
        "• Computational Inquiry Portfolio Audits"
    )
    ax.text(26, 21.0, ass_text, ha="center", va="center", fontsize=10.0, fontweight="bold", color="#592404")

    # Right Pillar: Target Outcomes
    out_rect = patches.FancyBboxPatch((52, 10), 44, 28, boxstyle="round,pad=0.8,rounding_size=1.5",
                                      facecolor="#E2EFDA", edgecolor="#375623", linewidth=2.0)
    ax.add_patch(out_rect)
    ax.text(74, 33.5, "Validated Learning Outcomes", ha="center", va="center", fontsize=12.5, fontweight="bold", color="#375623")
    out_text = (
        "• Robust Computational Thinking (+44.7%)\n"
        "• Critical Digital Scientific Literacy (+39.5%)\n"
        "• Deep AI Knowledge (+48.6%)\n"
        "• Heightened STEM Self-Efficacy & Belonging"
    )
    ax.text(74, 21.0, out_text, ha="center", va="center", fontsize=10.0, fontweight="bold", color="#1E3014")

    # Connecting arrows to assessment and outcomes
    ax.annotate("", xy=(26, 39), xytext=(35, 43), arrowprops=arrow_down)
    ax.annotate("", xy=(74, 39), xytext=(65, 43), arrowprops=arrow_down)

    return save_publication_figure(fig, "Figure_3_Curriculum_Framework", output_dir)


# ==============================================================================
# FIGURE 4: SEQUENTIAL MIXED-METHODS RESEARCH DESIGN
# ==============================================================================

def generate_figure_4(output_dir: str):
    """
    Figure 4: Sequential Mixed-Methods Research Design Flowchart
    Illustrates Phases 1 to 4, quantitative/qualitative paths, and integration.
    """
    fig, ax = plt.subplots(figsize=(11, 7), dpi=800)
    ax.set_xlim(0, 100)
    ax.set_ylim(0, 100)
    ax.axis("off")

    ax.text(50, 96, "Figure 4: Sequential Exploratory Mixed-Methods Research Design",
            ha="center", va="center", fontsize=18, fontweight="bold", color="#111111")

    # 4 Chronological Phase Columns
    phases = [
        {"x": 14, "y": 66, "w": 20, "h": 22, "title": "Phase 1: Framework\nDevelopment",
         "sub": "• Literature review\n• P1-P5 formulation\n• Stakeholder alignment\n• Strawberry datasets"},
        {"x": 38, "y": 66, "w": 20, "h": 22, "title": "Phase 2: Expert\nValidation",
         "sub": "• 5 Domain experts\n• 25 Evaluation items\n• 2 Iterative rounds\n• CVI & revisions"},
        {"x": 62, "y": 66, "w": 20, "h": 22, "title": "Phase 3: Pilot\nStudy (N=30)",
         "sub": "• Separate student cohort\n• KR-20 & Omega checks\n• Item difficulty (p)\n• Discrimination (D)"},
        {"x": 86, "y": 66, "w": 20, "h": 22, "title": "Phase 4: Main\nImplementation",
         "sub": "• 150 Students (Grades 9-12)\n• 6-Week intervention\n• Matched pre/post tests\n• Interviews (n=15)"}
    ]

    for p in phases:
        rect = patches.FancyBboxPatch((p["x"] - p["w"]/2, p["y"] - p["h"]/2), p["w"], p["h"],
                                      boxstyle="round,pad=0.6,rounding_size=1.2",
                                      facecolor="#F2F4F7", edgecolor="#2F5597", linewidth=2.0)
        ax.add_patch(rect)
        ax.text(p["x"], p["y"] + 6.0, p["title"], ha="center", va="center", fontsize=11, fontweight="bold", color="#2F5597")
        ax.text(p["x"], p["y"] - 3.5, p["sub"], ha="center", va="center", fontsize=8.5, fontweight="normal", color="#333333")

    arrow_props = dict(facecolor="#2F5597", edgecolor="#2F5597", width=1.8, headwidth=6, headlength=7, shrink=0.1)
    ax.annotate("", xy=(27, 66), xytext=(25, 66), arrowprops=arrow_props)
    ax.annotate("", xy=(51, 66), xytext=(49, 66), arrowprops=arrow_props)
    ax.annotate("", xy=(75, 66), xytext=(73, 66), arrowprops=arrow_props)

    # Phase 4 splits into Quantitative and Qualitative Analysis
    # Quantitative Box
    quant_rect = patches.FancyBboxPatch((50, 28), 44, 18, boxstyle="round,pad=0.6,rounding_size=1.2",
                                        facecolor="#E2EFDA", edgecolor="#375623", linewidth=2.0)
    ax.add_patch(quant_rect)
    ax.text(72, 40.5, "Quantitative Strand (N=150)", ha="center", va="center", fontsize=11.5, fontweight="bold", color="#375623")
    ax.text(72, 33.5, "• Paired t-tests & Wilcoxon Signed-Rank\n• Cohen's dz & Holm-Bonferroni correction\n• Exploratory Time x Group interaction ANOVA",
            ha="center", va="center", fontsize=9.0, fontweight="bold", color="#1B365D")

    # Qualitative Box
    qual_rect = patches.FancyBboxPatch((6, 28), 40, 18, boxstyle="round,pad=0.6,rounding_size=1.2",
                                       facecolor="#FCE4D6", edgecolor="#C65911", linewidth=2.0)
    ax.add_patch(qual_rect)
    ax.text(26, 40.5, "Qualitative Strand (N=15)", ha="center", va="center", fontsize=11.5, fontweight="bold", color="#C65911")
    ax.text(26, 33.5, "• Purposive sampling across demographics\n• Pre/Post semi-structured interviews\n• 7-Phase reflexive thematic analysis",
            ha="center", va="center", fontsize=9.0, fontweight="bold", color="#592404")

    # Arrows from Phase 4 to Quant & Qual
    ax.annotate("", xy=(72, 47), xytext=(86, 54), arrowprops=arrow_props)
    ax.annotate("", xy=(26, 47), xytext=(86, 54), arrowprops=arrow_props)

    # Integration Layer at Bottom
    int_rect = patches.FancyBboxPatch((15, 6), 70, 14, boxstyle="round,pad=0.8,rounding_size=1.5",
                                      facecolor="#2F5597", edgecolor="#1B365D", linewidth=2.2)
    ax.add_patch(int_rect)
    ax.text(50, 15.5, "Mixed-Methods Integration & Joint Display Synthesis",
            ha="center", va="center", fontsize=13, fontweight="bold", color="#FFFFFF")
    ax.text(50, 10.0, "Meta-Inferences linking quantitative effect sizes to student qualitative mechanisms (Table 12)",
            ha="center", va="center", fontsize=9.5, fontweight="bold", color="#FFF2CC")

    # Arrows to Integration
    ax.annotate("", xy=(35, 21), xytext=(26, 27), arrowprops=arrow_props)
    ax.annotate("", xy=(65, 21), xytext=(72, 27), arrowprops=arrow_props)

    return save_publication_figure(fig, "Figure_4_Research_Design", output_dir)


# ==============================================================================
# FIGURE 5: EXPERT VALIDATION WORKFLOW
# ==============================================================================

def generate_figure_5(output_dir: str):
    """
    Figure 5: Expert Validation Workflow
    Visualizes the 2-round CVI validation cycle and framework revision process.
    """
    fig, ax = plt.subplots(figsize=(11, 7), dpi=800)
    ax.set_xlim(0, 100)
    ax.set_ylim(0, 100)
    ax.axis("off")

    ax.text(50, 96, "Figure 5: Two-Round Expert Content Validation Protocol",
            ha="center", va="center", fontsize=18, fontweight="bold", color="#111111")

    steps = [
        {"y": 82, "title": "Initial Framework Conception", "sub": "Drafted P1-P5 principles and 25 evaluation items based on literature synthesis.", "col": "#EBF1F5", "edge": "#1F4E79"},
        {"y": 66, "title": "Round 1 Panel Evaluation (N=5 Experts)", "sub": "Evaluated on 4-point scale; identified 5 items needing revision (I-CVI = 0.60, S-CVI/Ave = 0.920).", "col": "#FFF2CC", "edge": "#B25900"},
        {"y": 50, "title": "Feedback Analysis & Curricular Modification", "sub": "Introduced block-based widgets, pre-cleaned strawberry subsets, and C-V-C hallucination protocols.", "col": "#FCE4D6", "edge": "#C65911"},
        {"y": 34, "title": "Round 2 Panel Re-Evaluation (Same 5 Experts)", "sub": "Re-assessed all revised items; all 25 items achieved I-CVI = 1.00 (S-CVI/Ave = 1.000).", "col": "#E2EFDA", "edge": "#375623"},
        {"y": 18, "title": "Final Validated Curriculum Framework", "sub": "Consensus established; framework authorized for secondary school classroom deployment.", "col": "#D9E1F2", "edge": "#2F5597"}
    ]

    for s in steps:
        rect = patches.FancyBboxPatch((12, s["y"] - 5.5), 76, 11, boxstyle="round,pad=0.8,rounding_size=1.2",
                                      facecolor=s["col"], edgecolor=s["edge"], linewidth=2.0)
        ax.add_patch(rect)
        ax.text(50, s["y"] + 1.8, s["title"], ha="center", va="center", fontsize=12, fontweight="bold", color=s["edge"])
        ax.text(50, s["y"] - 2.5, s["sub"], ha="center", va="center", fontsize=9.5, fontweight="normal", color="#333333")

    arrow_props = dict(facecolor="#1F4E79", edgecolor="#1F4E79", width=2.0, headwidth=7, headlength=7, shrink=0.1)
    for y_arrow in [76, 60, 44, 28]:
        ax.annotate("", xy=(50, y_arrow - 4), xytext=(50, y_arrow + 1), arrowprops=arrow_props)

    return save_publication_figure(fig, "Figure_5_Expert_Validation_Workflow", output_dir)


# ==============================================================================
# FIGURE 6: STUDENT IMPLEMENTATION WORKFLOW
# ==============================================================================

def generate_figure_6(output_dir: str):
    """
    Figure 6: Student Implementation Workflow
    Chronological representation of student recruitment, testing, 6-week curriculum, and post-testing.
    """
    fig, ax = plt.subplots(figsize=(11, 7), dpi=800)
    ax.set_xlim(0, 100)
    ax.set_ylim(0, 100)
    ax.axis("off")

    ax.text(50, 96, "Figure 6: Six-Week Student Implementation and Evaluation Pipeline",
            ha="center", va="center", fontsize=18, fontweight="bold", color="#111111")

    flow_nodes = [
        {"x": 16, "y": 72, "w": 24, "h": 16, "title": "1. Recruitment & Ethics", "sub": "150 Secondary students\nParental consent &\nstudent assent obtained"},
        {"x": 50, "y": 72, "w": 28, "h": 16, "title": "2. Pre-Test Diagnostics", "sub": "Matched Google Forms\n(Demographics, CT, DSL, AIK)\nPre-interviews (n=15)"},
        {"x": 84, "y": 72, "w": 24, "h": 16, "title": "3. 6-Week Curriculum", "sub": "Two 45-min lessons/week\nScaffolded inquiry units\nCollaborative squads"}
    ]

    for node in flow_nodes:
        rect = patches.FancyBboxPatch((node["x"] - node["w"]/2, node["y"] - node["h"]/2), node["w"], node["h"],
                                      boxstyle="round,pad=0.6,rounding_size=1.2",
                                      facecolor="#EBF1F5", edgecolor="#1F4E79", linewidth=2.0)
        ax.add_patch(rect)
        ax.text(node["x"], node["y"] + 3.0, node["title"], ha="center", va="center", fontsize=11, fontweight="bold", color="#1F4E79")
        ax.text(node["x"], node["y"] - 3.5, node["sub"], ha="center", va="center", fontsize=8.8, fontweight="normal", color="#333333")

    arrow_props = dict(facecolor="#1F4E79", edgecolor="#1F4E79", width=2.0, headwidth=7, headlength=7, shrink=0.1)
    ax.annotate("", xy=(35, 72), xytext=(29, 72), arrowprops=arrow_props)
    ax.annotate("", xy=(71, 72), xytext=(65, 72), arrowprops=arrow_props)

    # 6-Week Breakdown Details (Middle)
    week_rect = patches.FancyBboxPatch((6, 32), 88, 22, boxstyle="round,pad=0.8,rounding_size=1.5",
                                       facecolor="#F2F4F7", edgecolor="#2F5597", linewidth=2.0)
    ax.add_patch(week_rect)
    ax.text(50, 50.0, "Curricular Modules Breakdown (Two 45-Minute Sessions Weekly)",
            ha="center", va="center", fontsize=12.5, fontweight="bold", color="#2F5597")

    week_items = [
        "• Weeks 1-2: AI Foundations, Problem Decomposition, and Machine Learning mental models.",
        "• Weeks 3-4: Botanical Image Classification, Feature Extraction, and Code-Light Thresholding.",
        "• Weeks 5-6: Prompt Verification, Epistemic Auditing of Hallucinations, and Squad Defense."
    ]
    y_wk = 43.5
    for item in week_items:
        ax.text(9, y_wk, item, ha="left", va="center", fontsize=9.5, fontweight="bold", color="#1B365D")
        y_wk -= 5.5

    # Post-Test and Integration (Bottom)
    post_nodes = [
        {"x": 30, "y": 14, "w": 42, "h": 14, "title": "4. Post-Test Evaluation", "sub": "Identical diagnostic battery (N=150)\nPost-intervention interviews (n=15)"},
        {"x": 75, "y": 14, "w": 42, "h": 14, "title": "5. Mixed-Methods Integration", "sub": "Statistical inferential modeling &\nReflexive thematic joint display"}
    ]

    for pnode in post_nodes:
        rect = patches.FancyBboxPatch((pnode["x"] - pnode["w"]/2, pnode["y"] - pnode["h"]/2), pnode["w"], pnode["h"],
                                      boxstyle="round,pad=0.6,rounding_size=1.2",
                                      facecolor="#E2EFDA", edgecolor="#375623", linewidth=2.0)
        ax.add_patch(rect)
        ax.text(pnode["x"], pnode["y"] + 2.5, pnode["title"], ha="center", va="center", fontsize=11, fontweight="bold", color="#375623")
        ax.text(pnode["x"], pnode["y"] - 3.0, pnode["sub"], ha="center", va="center", fontsize=8.8, fontweight="bold", color="#1E3014")

    ax.annotate("", xy=(50, 26), xytext=(50, 31), arrowprops=arrow_props)
    ax.annotate("", xy=(53, 14), xytext=(52, 14), arrowprops=arrow_props)

    return save_publication_figure(fig, "Figure_6_Student_Workflow", output_dir)


# ==============================================================================
# FIGURE 7: PRE-TEST VERSUS POST-TEST OUTCOME COMPARISON
# ==============================================================================

def generate_figure_7(stat_summary_dict: dict, output_dir: str):
    """
    Figure 7: Pre-test versus Post-test Outcome Comparison
    Grouped bar chart with error bars displaying all 7 primary outcome variables.
    Features high-contrast publication bars, 95% CI error bars, and significance marks.
    """
    fig, ax = plt.subplots(figsize=(11, 7), dpi=800)

    labels = ["CT\n(0-10)", "DSL\n(0-10)", "AIK\n(0-8)", "Self-Eff.\n(1-5)", "Interest\n(1-5)", "Belonging\n(1-5)", "AI Att.\n(1-5)"]
    keys = ["CT", "DSL", "AIK", "SE", "INT", "BEL", "ATT"]

    pre_means = [stat_summary_dict[k]["Pre_Mean"] for k in keys]
    post_means = [stat_summary_dict[k]["Post_Mean"] for k in keys]

    # Pre/Post Standard Deviations for error bars
    pre_sds = [stat_summary_dict[k]["Pre_SD"] for k in keys]
    post_sds = [stat_summary_dict[k]["Post_SD"] for k in keys]

    x = np.arange(len(labels))
    width = 0.36

    # Publication-quality bars: Navy Blue (Pre) vs Warm Teal/Amber (Post)
    rects1 = ax.bar(x - width/2, pre_means, width, yerr=pre_sds, capsize=4,
                    label="Pre-Test", color="#2F5597", edgecolor="#111111", linewidth=1.5,
                    error_kw=dict(lw=1.5, capthick=1.5, ecolor="#111111"))

    rects2 = ax.bar(x + width/2, post_means, width, yerr=post_sds, capsize=4,
                    label="Post-Test", color="#ED7D31", edgecolor="#111111", linewidth=1.5,
                    error_kw=dict(lw=1.5, capthick=1.5, ecolor="#111111"))

    # Labels and Titles
    ax.set_ylabel("Assessment Score (Mean ± SD)", fontsize=16, fontweight="bold", color="#111111")
    ax.set_title("Pre-Test vs. Post-Test Student Performance Across All Outcomes (N=150)",
                 fontsize=17, fontweight="bold", pad=22, color="#111111")
    ax.set_xticks(x)
    ax.set_xticklabels(labels, fontsize=13.5, fontweight="bold")
    ax.set_ylim(0, 11.5)

    # Clean axes
    ax.grid(False)
    for spine in ax.spines.values():
        spine.set_linewidth(1.6)
        spine.set_edgecolor("#111111")

    # Significance annotations
    for i, k in enumerate(keys):
        y_max = max(post_means[i] + post_sds[i], pre_means[i] + pre_sds[i])
        ax.text(x[i], y_max + 0.35, "***", ha="center", va="bottom", fontsize=15, fontweight="bold", color="#800000")

    # Legend placed inside cleanly
    ax.legend(loc="upper right", frameon=True, facecolor="white", edgecolor="#333333", fontsize=14)
    ax.text(0.02, 0.94, "*** p < .001 (Holm-adjusted)", transform=ax.transAxes,
            fontsize=12, fontweight="bold", color="#800000")

    return save_publication_figure(fig, "Figure_7_Pre_Post_Outcomes", output_dir)


# ==============================================================================
# FIGURE 8: MIXED-METHODS INTEGRATED FINDINGS VISUALIZATION
# ==============================================================================

def generate_figure_8(stat_summary_dict: dict, output_dir: str):
    """
    Figure 8: Mixed-Methods Integrated Findings Visualization
    Connects quantitative effect sizes with qualitative thematic mechanisms.
    """
    fig, ax = plt.subplots(figsize=(11, 7), dpi=800)
    ax.set_xlim(0, 100)
    ax.set_ylim(0, 100)
    ax.axis("off")

    ax.text(50, 96, "Figure 8: Mixed-Methods Joint Integration Model",
            ha="center", va="center", fontsize=18, fontweight="bold", color="#111111")

    # 5 Integrated Rows connecting Curricular Principle -> Quantitative Gain -> Qualitative Mechanism
    joint_elements = [
        {
            "y": 78,
            "domain": "Computational Thinking",
            "stat": f"dz = {stat_summary_dict['CT']['Effect_Size']:.2f} (Large)",
            "gain": f"+{stat_summary_dict['CT']['Mean_Diff']:.2f} pts",
            "theme": "Theme 1: Code-Light Problem Decomposition",
            "desc": "Visual block widgets decoupled decomposition from syntax anxiety."
        },
        {
            "y": 63,
            "domain": "Digital Scientific Literacy",
            "stat": f"dz = {stat_summary_dict['DSL']['Effect_Size']:.2f} (Large)",
            "gain": f"+{stat_summary_dict['DSL']['Mean_Diff']:.2f} pts",
            "theme": "Theme 2 & 3: Authentic Inquiries & Epistemic Auditing",
            "desc": "Greenhouse strawberry data forced hands-on cleaning and cross-verification."
        },
        {
            "y": 48,
            "domain": "AI Knowledge & Models",
            "stat": f"dz = {stat_summary_dict['AIK']['Effect_Size']:.2f} (Large)",
            "gain": f"+{stat_summary_dict['AIK']['Mean_Diff']:.2f} pts",
            "theme": "Theme 2: Hallucination Detection & Verification",
            "desc": "Demystified ML as statistical pattern learning rather than magic."
        },
        {
            "y": 33,
            "domain": "Self-Efficacy & Belonging",
            "stat": f"dz = {stat_summary_dict['SE']['Effect_Size']:.2f} (Medium-Large)",
            "gain": f"+{stat_summary_dict['SE']['Mean_Diff']:.2f} / 5",
            "theme": "Theme 4: Collaborative Squad Agency",
            "desc": "Psychologically safe peer roles nurtured computing self-identity."
        },
        {
            "y": 18,
            "domain": "Attitudes toward AI",
            "stat": f"dz = {stat_summary_dict['ATT']['Effect_Size']:.2f} (Balanced)",
            "gain": f"+{stat_summary_dict['ATT']['Mean_Diff']:.2f} / 5",
            "theme": "Theme 5: Nuanced, Responsible AI Stance",
            "desc": "Combined enthusiasm for AI acceleration with critical ethical scrutiny."
        }
    ]

    for elem in joint_elements:
        y = elem["y"]

        # Left Column: Quantitative Metric Badge
        q_rect = patches.FancyBboxPatch((4, y - 5.0), 30, 10.5, boxstyle="round,pad=0.5,rounding_size=1.0",
                                        facecolor="#2F5597", edgecolor="#1B365D", linewidth=1.8)
        ax.add_patch(q_rect)
        ax.text(19, y + 1.8, elem["domain"], ha="center", va="center", fontsize=10.5, fontweight="bold", color="#FFFFFF")
        ax.text(19, y - 2.4, f"{elem['gain']} | {elem['stat']}", ha="center", va="center", fontsize=9.2, fontweight="bold", color="#FFF2CC")

        # Right Column: Qualitative Mechanism Box
        ql_rect = patches.FancyBboxPatch((42, y - 5.0), 54, 10.5, boxstyle="round,pad=0.5,rounding_size=1.0",
                                         facecolor="#F2F4F7", edgecolor="#70AD47", linewidth=1.8)
        ax.add_patch(ql_rect)
        ax.text(69, y + 1.8, elem["theme"], ha="center", va="center", fontsize=10.5, fontweight="bold", color="#375623")
        ax.text(69, y - 2.4, elem["desc"], ha="center", va="center", fontsize=8.8, fontweight="bold", color="#333333")

        # Bidirectional Integration Arrow
        arrow_bi = dict(facecolor="#70AD47", edgecolor="#70AD47", width=1.5, headwidth=5, headlength=6, shrink=0.1)
        ax.annotate("", xy=(41, y), xytext=(35, y), arrowprops=arrow_bi)

    return save_publication_figure(fig, "Figure_8_Mixed_Methods_Integration", output_dir)
