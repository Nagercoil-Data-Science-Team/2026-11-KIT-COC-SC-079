"""
Package initialization for AI-Integrated Science Curriculum Project source modules.
"""
