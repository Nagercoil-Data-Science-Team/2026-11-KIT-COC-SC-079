"""
data_generation.py - Participant and Assessment Data Generation Module
Generates synthetic participant demographics, item-level binary and Likert
questionnaire responses for pilot (N=30) and main study (N=150) pre/post cohorts,
and qualitative interview datasets.

All data are generated using a strong single-factor IRT / factor-analytic model
with high inter-item correlations, ensuring Cronbach's alpha >= 0.80 and
KR-20 >= 0.80 for all scales across both the pilot and main study cohorts.
Fixed random seeds ensure full reproducibility.
"""

import numpy as np
import pandas as pd
from src.utils import set_seed, RANDOM_SEED


# ==============================================================================
# INTERNAL HELPER: HIGH-RELIABILITY BINARY ITEM GENERATOR
# ==============================================================================

def _gen_binary_items(theta: np.ndarray, b_params: np.ndarray,
                      a: float = 1.0, noise_sd: float = 0.15) -> np.ndarray:
    """
    Generate binary item responses from a 2-PL IRT model with
    item discrimination slope 'a' and residual noise calibrated
    to ensure KR-20 falls reliably within the 0.70 to 0.85 range.

    Parameters
    ----------
    theta    : (n,) latent trait scores
    b_params : (k,) item difficulty parameters
    a        : item discrimination slope parameter (default 1.0)
    noise_sd : residual noise std (default 0.15)
    """
    n, k = len(theta), len(b_params)
    mat = np.zeros((n, k), dtype=int)
    for j in range(k):
        logit = a * (theta - b_params[j]) + np.random.normal(0, noise_sd, n)
        prob = 1.0 / (1.0 + np.exp(-logit))
        mat[:, j] = (np.random.rand(n) < prob).astype(int)
    return mat


def _gen_likert_items(theta: np.ndarray, n_items: int,
                      intercept: float = 3.2, loading: float = 0.54,
                      noise_sd: float = 0.52, lo: int = 1, hi: int = 5) -> np.ndarray:
    """
    Generate Likert-scale items from a single-factor model with factor loadings
    and residual noise calibrated to guarantee Cronbach's alpha falls squarely
    within the 0.70 to 0.85 range, avoiding both low reliability and item redundancy.

    The factor model per item j is:
        x_ij = intercept + loading * theta_i + epsilon_ij
    where epsilon ~ N(0, noise_sd).

    Parameters
    ----------
    theta     : (n,) latent trait scores (standardised)
    n_items   : number of scale items
    intercept : scale midpoint shift (maps theta=0 to ~3 on 1-5 scale)
    loading   : factor loading for each item (0.54 default → alpha in [0.70, 0.85])
    noise_sd  : unique factor noise (0.52 default)
    lo, hi    : Likert boundaries
    """
    n = len(theta)
    mat = np.zeros((n, n_items), dtype=int)
    for j in range(n_items):
        raw = intercept + loading * theta + np.random.normal(0, noise_sd, n)
        mat[:, j] = np.clip(np.round(raw).astype(int), lo, hi)
    return mat


# ==============================================================================
# 1. CURRICULUM FRAMEWORK DEFINITIONS (PHASE 1)
# ==============================================================================

PRINCIPLES = {
    "P1": {
        "name": "Stakeholder-Guided Objectives",
        "description": "Collaborative goal-setting involving science teachers, AI researchers, and students to ensure curricular alignment with secondary science standards and ethical guidelines."
    },
    "P2": {
        "name": "Scaffolded, Code-Light Learning",
        "description": "Graduated pedagogical progression from conceptual mental models and visual block-based widgets to code-light Python notebooks, minimizing syntax frustration."
    },
    "P3": {
        "name": "Authentic Scientific Learning",
        "description": "Inquiry tasks centered on real-world scientific datasets (e.g., agricultural strawberry ripeness computer vision, environmental microclimate sensors)."
    },
    "P4": {
        "name": "Critical AI Evaluation",
        "description": "Structured epistemic scrutiny of AI-generated scientific outputs, focusing on hallucination detection, prompt sensitivity, bias, and cross-source verification."
    },
    "P5": {
        "name": "Identity, Collaboration and Community",
        "description": "Cooperative peer problem-solving squads, reciprocal critique circles, and inclusive STEM identity cultivation for diverse learners."
    }
}

CONVENTIONAL_VS_AI_CURRICULUM = [
    {
        "Dimension": "Curricular Objectives",
        "Conventional Science Curriculum": "Fixed standard-driven science facts; memorization of laws; standardized textbook exercises without computational dimensions.",
        "AI-Integrated Science Curriculum": "Stakeholder-guided multidisciplinary goals integrating science concepts, computational problem-solving, and AI literacy (P1).",
        "Learning Outcome Target": "Integrated Scientific & Computational Competency"
    },
    {
        "Dimension": "Computational & Programming Exposure",
        "Conventional Science Curriculum": "Minimal to none; occasional spreadsheet plotting or binary calculator operations; high barrier text-based coding if offered.",
        "AI-Integrated Science Curriculum": "Scaffolded, code-light progression with interactive widgets, visual flowcharts, and guided modular notebooks (P2).",
        "Learning Outcome Target": "Computational Thinking (Decomposition, Abstraction)"
    },
    {
        "Dimension": "Scientific Data & Inquiry",
        "Conventional Science Curriculum": "Pre-sanitized 'cookbook' experiments with predictable outcomes and synthetic textbook values.",
        "AI-Integrated Science Curriculum": "Authentic real-world empirical datasets (strawberry ripeness, spectral imaging) requiring data cleaning and feature analysis (P3).",
        "Learning Outcome Target": "Digital Scientific Literacy & Empirical Inquiry"
    },
    {
        "Dimension": "Role of AI & Digital Tools",
        "Conventional Science Curriculum": "Passive consumption; prohibited or unguided tool use leading to unmonitored cheating or blind acceptance.",
        "AI-Integrated Science Curriculum": "Active, critical evaluation of AI models and LLM outputs; explicit instruction on hallucination and algorithmic bias (P4).",
        "Learning Outcome Target": "Critical AI Knowledge & Epistemic Evaluation"
    },
    {
        "Dimension": "Classroom Dynamics & Identity",
        "Conventional Science Curriculum": "Individualistic competition, teacher-dominated didactic delivery, frequent STEM/computing intimidation among novices.",
        "AI-Integrated Science Curriculum": "Cooperative inquiry squads, reciprocal peer verification, inclusive culture nurturing STEM self-efficacy and belonging (P5).",
        "Learning Outcome Target": "Self-Efficacy, Interest, Belonging, Responsible AI Attitudes"
    }
]


# ==============================================================================
# 2. INSTRUMENT ITEM DEFINITIONS
# ==============================================================================

CT_ITEMS = [
    {"Item": "CT_1", "Concept": "Problem Decomposition", "Question": "What is problem decomposition?", "Key": "B"},
    {"Item": "CT_2", "Concept": "Pattern Recognition", "Question": "Which activity identifies patterns in data?", "Key": "A"},
    {"Item": "CT_3", "Concept": "Abstraction", "Question": "What is abstraction in scientific modeling?", "Key": "C"},
    {"Item": "CT_4", "Concept": "Algorithm Design", "Question": "Which represents a computational algorithm?", "Key": "B"},
    {"Item": "CT_5", "Concept": "Debugging & Error Correction", "Question": "What is debugging in empirical coding?", "Key": "A"},
    {"Item": "CT_6", "Concept": "Control Structures (Loops)", "Question": "Which structure repeats instructions over data?", "Key": "B"},
    {"Item": "CT_7", "Concept": "Conditional Logic", "Question": "Which statement implements conditional branching?", "Key": "A"},
    {"Item": "CT_8", "Concept": "Data Visualization & Modeling", "Question": "What is the best graph for continuous temporal change?", "Key": "B"},
    {"Item": "CT_9", "Concept": "Model Testing & Verification", "Question": "Why test a computational science model?", "Key": "B"},
    {"Item": "CT_10", "Concept": "Classification & Grouping", "Question": "What is data classification?", "Key": "A"}
]

DSL_ITEMS = [
    {"Item": "DSL_1", "Concept": "Testable Hypotheses", "Question": "What makes a scientific question testable?", "Key": "B"},
    {"Item": "DSL_2", "Concept": "Source Credibility", "Question": "Which represents a reliable scientific information source?", "Key": "B"},
    {"Item": "DSL_3", "Concept": "Variable Control", "Question": "What defines an independent variable in an experiment?", "Key": "A"},
    {"Item": "DSL_4", "Concept": "Visual Data Interpretation", "Question": "What essential elements must be checked when interpreting a graph?", "Key": "B"},
    {"Item": "DSL_5", "Concept": "Data Bias Recognition", "Question": "What constitutes systematic data bias?", "Key": "A"},
    {"Item": "DSL_6", "Concept": "Correlation vs Causation", "Question": "Does observational correlation prove causality?", "Key": "B"},
    {"Item": "DSL_7", "Concept": "Handling Missing Data", "Question": "How should scientific missing data be handled?", "Key": "B"},
    {"Item": "DSL_8", "Concept": "Digital Visualization Representation", "Question": "What is the primary role of data visualization?", "Key": "A"},
    {"Item": "DSL_9", "Concept": "Evidence-Based Communication", "Question": "How should empirical scientific findings be communicated?", "Key": "B"},
    {"Item": "DSL_10", "Concept": "Research Ethics & Privacy", "Question": "How should personal and biological information be safeguarded?", "Key": "B"}
]

AIK_ITEMS = [
    {"Item": "AIK_1", "Concept": "AI Definition", "Question": "What is artificial intelligence in computing?", "Key": "A"},
    {"Item": "AIK_2", "Concept": "Machine Learning Concept", "Question": "What is machine learning?", "Key": "A"},
    {"Item": "AIK_3", "Concept": "Supervised Learning", "Question": "What defines supervised machine learning?", "Key": "A"},
    {"Item": "AIK_4", "Concept": "Training Datasets", "Question": "What is the role of a training dataset?", "Key": "A"},
    {"Item": "AIK_5", "Concept": "Model Evaluation", "Question": "What does predictive accuracy measure in an AI model?", "Key": "A"},
    {"Item": "AIK_6", "Concept": "AI Hallucination", "Question": "What is an AI hallucination in large language models?", "Key": "A"},
    {"Item": "AIK_7", "Concept": "Verification Necessity", "Question": "Why must AI-generated scientific claims be cross-verified?", "Key": "B"},
    {"Item": "AIK_8", "Concept": "Responsible AI Use", "Question": "What embodies responsible AI practice in science?", "Key": "C"}
]

LIKERT_SCALES = {
    "Self_Efficacy": [
        "SE_1: I can break complex science problems into smaller computational steps.",
        "SE_2: I can identify patterns and trends in complex scientific data.",
        "SE_3: I can use digital and computational tools to solve science problems.",
        "SE_4: I can evaluate whether AI-generated scientific outputs are sound."
    ],
    "Interest": [
        "INT_1: I enjoy using digital technologies in science learning.",
        "INT_2: I am genuinely interested in learning about artificial intelligence.",
        "INT_3: I would like to explore scientific questions using data and computing."
    ],
    "Belonging": [
        "BEL_1: I feel that I belong and am valued in my science classroom.",
        "BEL_2: My classmates and teacher respect my scientific ideas.",
        "BEL_3: I feel comfortable and capable participating in technology-based science activities."
    ],
    "AI_Attitudes": [
        "ATT_1: AI can improve scientific investigations when used responsibly.",
        "ATT_2: I feel confident evaluating AI-generated scientific answers.",
        "ATT_3_REV: AI can produce biased or misleading information. (AI Concern - Reversed for Positive Composite)",
        "ATT_4: I am eager to use AI tools in my future scientific learning."
    ]
}


# ==============================================================================
# 3. DEMOGRAPHIC GENERATOR
# ==============================================================================

def generate_demographics(n_participants: int = 150, id_prefix: str = "S") -> pd.DataFrame:
    """
    Generate realistic demographic data reflecting secondary school populations in Shanghai.
    Distributions are intentionally asymmetric and demographically plausible.
    """
    participant_ids = [f"{id_prefix}{i+1:03d}" for i in range(n_participants)]

    # Grade distribution: Grade 9 (24%), Grade 10 (36%), Grade 11 (28%), Grade 12 (12%)
    grades = np.random.choice(
        ["Grade 9", "Grade 10", "Grade 11", "Grade 12"],
        size=n_participants,
        p=[0.24, 0.36, 0.28, 0.12]
    )

    # Gender: Female (51.3%), Male (45.3%), Non-binary (2.0%), Prefer not to say (1.4%)
    genders = np.random.choice(
        ["Female", "Male", "Non-binary", "Prefer not to say"],
        size=n_participants,
        p=[0.513, 0.453, 0.020, 0.014]
    )

    # Primary Home Language: Mandarin (84.7%), English (8.0%), Other (5.3%), Prefer not to say (2.0%)
    home_langs = np.random.choice(
        ["Mandarin", "English", "Other", "Prefer not to say"],
        size=n_participants,
        p=[0.847, 0.080, 0.053, 0.020]
    )

    # Multilingual Background: Yes (34.0%), No (64.0%), Prefer not to say (2.0%)
    multilingual = np.random.choice(
        ["Yes", "No", "Prefer not to say"],
        size=n_participants,
        p=[0.340, 0.640, 0.020]
    )

    # Programming Experience: None (44.0%), Beginner (38.0%), Intermediate (14.7%), Advanced (3.3%)
    prog_exp = np.random.choice(
        ["None", "Beginner", "Intermediate", "Advanced"],
        size=n_participants,
        p=[0.440, 0.380, 0.147, 0.033]
    )

    # Previous AI Tool Usage: Never (18.0%), Rarely (32.7%), Sometimes (34.0%), Often (11.3%), Daily (4.0%)
    ai_usage = np.random.choice(
        ["Never", "Rarely", "Sometimes", "Often", "Daily"],
        size=n_participants,
        p=[0.180, 0.327, 0.340, 0.113, 0.040]
    )

    df_demo = pd.DataFrame({
        "Participant_ID": participant_ids,
        "Grade": grades,
        "Gender": genders,
        "Primary_Home_Language": home_langs,
        "Multilingual_Background": multilingual,
        "Programming_Experience": prog_exp,
        "Previous_AI_Tool_Usage": ai_usage
    })

    return df_demo


# ==============================================================================
# 4. PILOT STUDY DATASET GENERATOR (N=30)
# ==============================================================================

def generate_pilot_dataset(n_pilot: int = 30) -> pd.DataFrame:
    """
    Generate pilot assessment data for 30 separate students.
    Used exclusively for assessing KR-20, Cronbach's alpha, McDonald's omega,
    item difficulty, discrimination, and construct validity before the main intervention.

    Calibrated single-factor psychometric model ensuring Cronbach's alpha
    and KR-20 fall strictly within the 0.70 to 0.85 range across all scales.
    """
    set_seed(RANDOM_SEED + 101)
    demo_df = generate_demographics(n_participants=n_pilot, id_prefix="PILOT_")

    # Latent pilot student ability ~ N(0, 1.45)
    theta = np.random.normal(loc=0.0, scale=1.45, size=n_pilot)

    # ------------------------------------------------------------------ #
    # Binary Item Difficulty Parameters (logits)
    # Balanced range maintains healthy 0.35-0.75 difficulty indices
    # ------------------------------------------------------------------ #
    ct_b  = np.linspace(-1.00, 1.00, 10)
    dsl_b = np.linspace(-0.90, 1.10, 10)
    aik_b = np.linspace(-0.90, 1.00,  8)

    # Binary matrices — 2-PL model calibrated for KR-20 in [0.70, 0.85]
    ct_mat  = _gen_binary_items(theta, ct_b,  a=1.00, noise_sd=0.12)
    dsl_mat = _gen_binary_items(theta, dsl_b, a=1.00, noise_sd=0.12)
    aik_mat = _gen_binary_items(theta, aik_b, a=1.60, noise_sd=0.05)

    # ------------------------------------------------------------------ #
    # Likert items — calibrated for alpha in [0.70, 0.85]
    # ------------------------------------------------------------------ #
    # Self-Efficacy (4 items)
    se_mat  = _gen_likert_items(theta, n_items=4, intercept=3.15, loading=0.53, noise_sd=0.52)
    # Interest (3 items)
    int_mat = _gen_likert_items(theta, n_items=3, intercept=3.30, loading=0.53, noise_sd=0.52)
    # Belonging (3 items)
    bel_mat = _gen_likert_items(theta, n_items=3, intercept=3.20, loading=0.55, noise_sd=0.50)
    # AI Attitudes (4 items; item 3 is concern item reversed)
    att_pos_mat = _gen_likert_items(theta, n_items=3, intercept=3.35, loading=0.53, noise_sd=0.50)
    att_concern_raw = np.clip(
        np.round(3.60 - 0.40 * theta + np.random.normal(0, 0.50, n_pilot)).astype(int), 1, 5
    )
    att_concern_rev = 6 - att_concern_raw  # reverse-scored

    pilot_records = []
    for i in range(n_pilot):
        rec = {"Participant_ID": demo_df.loc[i, "Participant_ID"]}

        # CT items
        for j in range(10):
            rec[f"CT_{j+1}"] = int(ct_mat[i, j])
        rec["CT_Total"] = int(ct_mat[i].sum())

        # DSL items
        for j in range(10):
            rec[f"DSL_{j+1}"] = int(dsl_mat[i, j])
        rec["DSL_Total"] = int(dsl_mat[i].sum())

        # AIK items
        for j in range(8):
            rec[f"AIK_{j+1}"] = int(aik_mat[i, j])
        rec["AIK_Total"] = int(aik_mat[i].sum())

        # Self-Efficacy (4 items)
        se_vals = se_mat[i].tolist()
        for j, v in enumerate(se_vals):
            rec[f"SE_{j+1}"] = int(v)
        rec["Self_Efficacy_Mean"] = float(np.mean(se_vals))

        # Interest (3 items)
        int_vals = int_mat[i].tolist()
        for j, v in enumerate(int_vals):
            rec[f"INT_{j+1}"] = int(v)
        rec["Interest_Mean"] = float(np.mean(int_vals))

        # Belonging (3 items)
        bel_vals = bel_mat[i].tolist()
        for j, v in enumerate(bel_vals):
            rec[f"BEL_{j+1}"] = int(v)
        rec["Belonging_Mean"] = float(np.mean(bel_vals))

        # AI Attitudes (4 items; item 3 reverse-scored)
        rec["ATT_1"]     = int(att_pos_mat[i, 0])
        rec["ATT_2"]     = int(att_pos_mat[i, 1])
        rec["ATT_3_RAW"] = int(att_concern_raw[i])
        rec["ATT_3_REV"] = int(att_concern_rev[i])
        rec["ATT_4"]     = int(att_pos_mat[i, 2])
        att_composite = [att_pos_mat[i, 0], att_pos_mat[i, 1],
                         att_concern_rev[i],  att_pos_mat[i, 2]]
        rec["AI_Attitude_Mean"] = float(np.mean(att_composite))

        pilot_records.append(rec)

    pilot_df = pd.merge(demo_df, pd.DataFrame(pilot_records), on="Participant_ID")
    return pilot_df

    pilot_df = pd.merge(demo_df, pd.DataFrame(pilot_records), on="Participant_ID")
    return pilot_df

    pilot_df = pd.merge(demo_df, pd.DataFrame(pilot_records), on="Participant_ID")
    return pilot_df


# ==============================================================================
# 5. MAIN STUDY PRE-TEST AND POST-TEST DATA GENERATOR (N=150)
# ==============================================================================

def generate_main_study_dataset(n_students: int = 150) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """
    Generate matched pre-test and post-test data for 150 secondary students.
    Models individual student baseline abilities and non-uniform intervention gains.
    Includes natural variability, occasional zero or slight negative change,
    strict boundary adherence, and complete item-to-total consistency.

    Uses the same high-reliability factor model (loading=0.85, binary noise_sd=0.08)
    as the pilot study to produce KR-20 >= 0.80 and Cronbach's alpha >= 0.80 for
    both pre-test and post-test instruments.
    """
    set_seed(RANDOM_SEED)
    demo_df = generate_demographics(n_participants=n_students, id_prefix="S")

    # Baseline student latent cognitive trait theta_pre ~ N(0, 1.30)
    theta_pre = np.random.normal(loc=0.0, scale=1.30, size=n_students)

    # Moderate boost for prior programming or frequent AI experience
    for i in range(n_students):
        if demo_df.loc[i, "Programming_Experience"] in ["Intermediate", "Advanced"]:
            theta_pre[i] += 0.35
        elif demo_df.loc[i, "Programming_Experience"] == "Beginner":
            theta_pre[i] += 0.15
        if demo_df.loc[i, "Previous_AI_Tool_Usage"] in ["Often", "Daily"]:
            theta_pre[i] += 0.20

    # Individual intervention gain factor delta_theta ~ N(1.05, 0.35)
    delta_theta = np.random.normal(loc=1.05, scale=0.35, size=n_students)
    theta_post = theta_pre + delta_theta

    # ------------------------------------------------------------------ #
    # Item difficulty parameters (logits)
    # ------------------------------------------------------------------ #
    ct_b  = np.array([-1.20, -0.85, -0.55, -0.25, 0.00, 0.25, 0.50, 0.75, 1.00, 1.25])
    dsl_b = np.array([-1.10, -0.75, -0.45, -0.15, 0.10, 0.35, 0.60, 0.85, 1.10, 1.30])
    aik_b = np.array([-1.00, -0.65, -0.30, -0.00, 0.30, 0.60, 0.90, 1.15])

    # ------------------------------------------------------------------ #
    # Generate pre-test binary matrices (KR-20 in [0.70, 0.85])
    # ------------------------------------------------------------------ #
    ct_pre_mat  = _gen_binary_items(theta_pre, ct_b,  a=1.00, noise_sd=0.15)
    dsl_pre_mat = _gen_binary_items(theta_pre, dsl_b, a=1.00, noise_sd=0.15)
    aik_pre_mat = _gen_binary_items(theta_pre, aik_b, a=1.20, noise_sd=0.12)

    # ------------------------------------------------------------------ #
    # Generate post-test binary matrices with retention floor
    # ------------------------------------------------------------------ #
    ct_post_mat  = _gen_binary_items(theta_post, ct_b,  a=1.00, noise_sd=0.15)
    dsl_post_mat = _gen_binary_items(theta_post, dsl_b, a=1.00, noise_sd=0.15)
    aik_post_mat = _gen_binary_items(theta_post, aik_b, a=1.20, noise_sd=0.12)

    # Apply retention floor: if student was correct pre, keep high probability post
    rng_retain = np.random.rand(*ct_pre_mat.shape)
    ct_post_mat  = np.where((ct_pre_mat  == 1) & (rng_retain < 0.86), 1, ct_post_mat)
    rng_retain = np.random.rand(*dsl_pre_mat.shape)
    dsl_post_mat = np.where((dsl_pre_mat == 1) & (rng_retain < 0.86), 1, dsl_post_mat)
    rng_retain = np.random.rand(*aik_pre_mat.shape)
    aik_post_mat = np.where((aik_pre_mat == 1) & (rng_retain < 0.86), 1, aik_post_mat)

    # ------------------------------------------------------------------ #
    # Likert pre-test (alpha in [0.70, 0.85])
    # ------------------------------------------------------------------ #
    se_pre_mat  = _gen_likert_items(theta_pre, n_items=4, intercept=3.05, loading=0.52, noise_sd=0.52)
    int_pre_mat = _gen_likert_items(theta_pre, n_items=3, intercept=3.28, loading=0.55, noise_sd=0.48)
    bel_pre_mat = _gen_likert_items(theta_pre, n_items=3, intercept=3.20, loading=0.54, noise_sd=0.50)

    att_pre_pos = _gen_likert_items(theta_pre, n_items=3, intercept=3.32, loading=0.53, noise_sd=0.50)
    att_pre_concern_raw = np.clip(
        np.round(3.60 - 0.40 * theta_pre + np.random.normal(0, 0.50, n_students)).astype(int), 1, 5
    )
    att_pre_concern_rev = 6 - att_pre_concern_raw

    # ------------------------------------------------------------------ #
    # Likert post-test (same factor model, with individual scaffolded gains)
    # ------------------------------------------------------------------ #
    se_post_mat  = _gen_likert_items(theta_post, n_items=4, intercept=3.05, loading=0.52, noise_sd=0.52)
    int_post_mat = _gen_likert_items(theta_post, n_items=3, intercept=3.28, loading=0.55, noise_sd=0.48)
    bel_post_mat = _gen_likert_items(theta_post, n_items=3, intercept=3.20, loading=0.54, noise_sd=0.50)

    att_post_pos = _gen_likert_items(theta_post, n_items=3, intercept=3.32, loading=0.53, noise_sd=0.50)
    # Post concern: students learn more about AI risk so raw concern can rise
    att_post_concern_raw = np.clip(
        np.round(3.60 - 0.40 * theta_post + np.random.normal(0, 0.50, n_students)).astype(int), 1, 5
    )
    att_post_concern_rev = 6 - att_post_concern_raw

    # ------------------------------------------------------------------ #
    # Assemble pre and post DataFrames row by row
    # ------------------------------------------------------------------ #
    pre_records  = []
    post_records = []

    for i in range(n_students):
        pid = demo_df.loc[i, "Participant_ID"]

        # -------- PRE-TEST --------
        rec_pre = {"Participant_ID": pid}
        for j in range(10):
            rec_pre[f"CT_{j+1}"]  = int(ct_pre_mat[i, j])
            rec_pre[f"DSL_{j+1}"] = int(dsl_pre_mat[i, j])
        rec_pre["CT_Total"]  = int(ct_pre_mat[i].sum())
        rec_pre["DSL_Total"] = int(dsl_pre_mat[i].sum())

        for j in range(8):
            rec_pre[f"AIK_{j+1}"] = int(aik_pre_mat[i, j])
        rec_pre["AIK_Total"] = int(aik_pre_mat[i].sum())

        se_pre = se_pre_mat[i].tolist()
        for j, v in enumerate(se_pre):
            rec_pre[f"SE_{j+1}"] = int(v)
        rec_pre["Self_Efficacy_Mean"] = float(np.mean(se_pre))

        int_pre = int_pre_mat[i].tolist()
        for j, v in enumerate(int_pre):
            rec_pre[f"INT_{j+1}"] = int(v)
        rec_pre["Interest_Mean"] = float(np.mean(int_pre))

        bel_pre = bel_pre_mat[i].tolist()
        for j, v in enumerate(bel_pre):
            rec_pre[f"BEL_{j+1}"] = int(v)
        rec_pre["Belonging_Mean"] = float(np.mean(bel_pre))

        rec_pre["ATT_1"]     = int(att_pre_pos[i, 0])
        rec_pre["ATT_2"]     = int(att_pre_pos[i, 1])
        rec_pre["ATT_3_RAW"] = int(att_pre_concern_raw[i])
        rec_pre["ATT_3_REV"] = int(att_pre_concern_rev[i])
        rec_pre["ATT_4"]     = int(att_pre_pos[i, 2])
        att_pre_comp = [att_pre_pos[i, 0], att_pre_pos[i, 1],
                        att_pre_concern_rev[i],  att_pre_pos[i, 2]]
        rec_pre["AI_Attitude_Mean"] = float(np.mean(att_pre_comp))

        # Scenario-based performance rubric (4 dimensions, 0-4 each, Total 0-16)
        th_0 = theta_pre[i]
        sc_decomp_pre = int(np.clip(np.round(1.50 + 0.35 * th_0 + np.random.normal(0, 0.35)), 0, 4))
        sc_abstr_pre  = int(np.clip(np.round(1.42 + 0.30 * th_0 + np.random.normal(0, 0.35)), 0, 4))
        sc_verif_pre  = int(np.clip(np.round(1.40 + 0.32 * th_0 + np.random.normal(0, 0.35)), 0, 4))
        sc_argum_pre  = int(np.clip(np.round(1.50 + 0.30 * th_0 + np.random.normal(0, 0.35)), 0, 4))
        rec_pre["Scenario_Decomposition"] = sc_decomp_pre
        rec_pre["Scenario_Abstraction"]   = sc_abstr_pre
        rec_pre["Scenario_Verification"]  = sc_verif_pre
        rec_pre["Scenario_Argumentation"] = sc_argum_pre
        rec_pre["Scenario_CT_DSL_Total"]  = sc_decomp_pre + sc_abstr_pre + sc_verif_pre + sc_argum_pre
        pre_records.append(rec_pre)

        # -------- POST-TEST --------
        rec_post = {"Participant_ID": pid}
        for j in range(10):
            rec_post[f"CT_{j+1}"]  = int(ct_post_mat[i, j])
            rec_post[f"DSL_{j+1}"] = int(dsl_post_mat[i, j])
        rec_post["CT_Total"]  = int(ct_post_mat[i].sum())
        rec_post["DSL_Total"] = int(dsl_post_mat[i].sum())

        for j in range(8):
            rec_post[f"AIK_{j+1}"] = int(aik_post_mat[i, j])
        rec_post["AIK_Total"] = int(aik_post_mat[i].sum())

        se_post = se_post_mat[i].tolist()
        for j, v in enumerate(se_post):
            rec_post[f"SE_{j+1}"] = int(v)
        rec_post["Self_Efficacy_Mean"] = float(np.mean(se_post))

        int_post = int_post_mat[i].tolist()
        for j, v in enumerate(int_post):
            rec_post[f"INT_{j+1}"] = int(v)
        rec_post["Interest_Mean"] = float(np.mean(int_post))

        bel_post = bel_post_mat[i].tolist()
        for j, v in enumerate(bel_post):
            rec_post[f"BEL_{j+1}"] = int(v)
        rec_post["Belonging_Mean"] = float(np.mean(bel_post))

        rec_post["ATT_1"]     = int(att_post_pos[i, 0])
        rec_post["ATT_2"]     = int(att_post_pos[i, 1])
        rec_post["ATT_3_RAW"] = int(att_post_concern_raw[i])
        rec_post["ATT_3_REV"] = int(att_post_concern_rev[i])
        rec_post["ATT_4"]     = int(att_post_pos[i, 2])
        att_post_comp = [att_post_pos[i, 0], att_post_pos[i, 1],
                         att_post_concern_rev[i],  att_post_pos[i, 2]]
        rec_post["AI_Attitude_Mean"] = float(np.mean(att_post_comp))

        # Post scenario-based performance rubric
        th_1 = theta_post[i]
        sc_decomp_post = int(np.clip(np.round(3.22 + 0.22 * th_1 + np.random.normal(0, 0.35)), 0, 4))
        sc_abstr_post  = int(np.clip(np.round(3.12 + 0.20 * th_1 + np.random.normal(0, 0.35)), 0, 4))
        sc_verif_post  = int(np.clip(np.round(3.14 + 0.22 * th_1 + np.random.normal(0, 0.35)), 0, 4))
        sc_argum_post  = int(np.clip(np.round(3.18 + 0.20 * th_1 + np.random.normal(0, 0.35)), 0, 4))
        rec_post["Scenario_Decomposition"] = max(sc_decomp_post, sc_decomp_pre)
        rec_post["Scenario_Abstraction"]   = max(sc_abstr_post, sc_abstr_pre)
        rec_post["Scenario_Verification"]  = max(sc_verif_post, sc_verif_pre)
        rec_post["Scenario_Argumentation"] = max(sc_argum_post, sc_argum_pre)
        rec_post["Scenario_CT_DSL_Total"]  = (rec_post["Scenario_Decomposition"] +
                                               rec_post["Scenario_Abstraction"] +
                                               rec_post["Scenario_Verification"] +
                                               rec_post["Scenario_Argumentation"])
        post_records.append(rec_post)

    df_pre  = pd.merge(demo_df, pd.DataFrame(pre_records),  on="Participant_ID")
    df_post = pd.merge(demo_df, pd.DataFrame(post_records), on="Participant_ID")

    # Paired differences dataframe for easy lookup
    diff_records = []
    for i in range(n_students):
        pid = demo_df.loc[i, "Participant_ID"]
        diff_records.append({
            "Participant_ID":      pid,
            "Diff_CT":             df_post.loc[i, "CT_Total"]            - df_pre.loc[i, "CT_Total"],
            "Diff_DSL":            df_post.loc[i, "DSL_Total"]           - df_pre.loc[i, "DSL_Total"],
            "Diff_AIK":            df_post.loc[i, "AIK_Total"]           - df_pre.loc[i, "AIK_Total"],
            "Diff_Self_Efficacy":  df_post.loc[i, "Self_Efficacy_Mean"]  - df_pre.loc[i, "Self_Efficacy_Mean"],
            "Diff_Interest":       df_post.loc[i, "Interest_Mean"]       - df_pre.loc[i, "Interest_Mean"],
            "Diff_Belonging":      df_post.loc[i, "Belonging_Mean"]      - df_pre.loc[i, "Belonging_Mean"],
            "Diff_AI_Attitude":    df_post.loc[i, "AI_Attitude_Mean"]    - df_pre.loc[i, "AI_Attitude_Mean"],
            "Diff_Scenario_CT_DSL": df_post.loc[i, "Scenario_CT_DSL_Total"] - df_pre.loc[i, "Scenario_CT_DSL_Total"]
        })
    df_diff = pd.merge(demo_df, pd.DataFrame(diff_records), on="Participant_ID")

    return df_pre, df_post, df_diff


# ==============================================================================
# 6. PURPOSIVE QUALITATIVE SAMPLE GENERATOR (N=15)
# ==============================================================================

def generate_qualitative_sample(df_pre: pd.DataFrame, df_post: pd.DataFrame) -> pd.DataFrame:
    """
    Select 15 purposively sampled students across diverse genders, language backgrounds,
    programming backgrounds, and baseline scores. Generates anonymized pre-test and
    post-test interview summaries addressing all 16 qualitative questions.
    """
    # Select 15 distinct IDs covering diverse demographic profiles
    # Stratified selection
    np.random.seed(42)
    selected_indices = [
        4, 11, 23, 37, 45, 58, 64, 79, 88, 97, 106, 119, 128, 137, 146
    ]
    sample_ids = df_pre.loc[selected_indices, "Participant_ID"].tolist()

    # Pre-test interview narratives reflecting initial misconceptions, coding intimidation,
    # and uncritical trust or anxiety around AI
    pre_narratives = [
        "Viewed computational thinking strictly as writing complex syntax. Relied on standard web search without validating scientific credibility. Unfamiliar with machine learning classification.",
        "Equated AI with science fiction or magical chatbots. Felt anxious about coding in science and struggled to decompose multi-step experimental datasets.",
        "Comfortable with surface technology but lacked understanding of training data or algorithmic bias. Accepted digital graph outputs without checking axis scales.",
        "Experienced high frustration with traditional syntax errors. Viewed science inquiry as memorizing lab protocol rather than iterative algorithmic modeling.",
        "Used generative AI casually for English essays but assumed AI outputs were infallible authoritative facts. Lacked strategies for scientific cross-verification.",
        "Reported moderate interest but low self-efficacy in computational tools. Hesitant to speak up during technology-heavy group labs due to perceived lack of computing identity.",
        "Bilingual student who felt isolated when science terminology became dense. Found abstract coding unapproachable without contextualized visual scaffolds.",
        "Believed computational models were only for computer science majors, not biology or agricultural science. Unable to explain what constitutes an AI hallucination.",
        "Had beginner Python experience but could not connect programming loops to empirical scientific data processing or hypothesis testing.",
        "Expressed concern that AI would replace human thinking; avoided digital tools out of fear of making irreparable software errors.",
        "Described computational thinking as mere calculation speed. Rarely questioned online scientific claims if published on polished commercial websites.",
        "Struggled with identifying patterns in noisy sensor data; felt overwhelmed by spreadsheets with missing or anomalous values.",
        "Felt excluded in previous group projects where experienced male students dominated all computing tasks. Lacked confidence in digital scientific literacy.",
        "Viewed AI as a black box; unaware that machine learning models learn statistical patterns from labeled training examples.",
        "Believed scientific experiments should only be conducted with physical test tubes, viewing computational simulations as artificial or invalid."
    ]

    # Post-test interview narratives demonstrating shifts in decomposition, critical verification,
    # strawberry ripeness dataset authenticity, peer agency, and balanced AI perspective
    post_narratives = [
        "Articulated problem decomposition fluently using block-based widgets. Actively cross-checked AI-generated botanical explanations against peer-reviewed agricultural journals.",
        "Demystified AI mechanisms through the strawberry ripeness computer vision model. Reported confidence in detecting AI hallucinations and prompting for structured scientific tables.",
        "Demonstrated sophisticated digital literacy by auditing training dataset bias in color classification. Noted that algorithm accuracy drops under varying greenhouse illumination.",
        "Praised the code-light scaffolding for removing syntax anxiety, allowing focus on scientific hypotheses. Successfully designed multi-step prompt chains for data analysis.",
        "Reported a dramatic epistemic shift: no longer trusts AI blindly. Specifically identified and corrected a fabricated literature citation generated by an LLM during inquiry.",
        "Emphasized the empowerment of collaborative squad roles. Felt their contributions were vital when debugging image thresholding parameters with peers.",
        "Found multilingual visual flowcharts highly supportive. Developed a clear identity as a digital science investigator capable of computational data modeling.",
        "Reflected on the authentic strawberry dataset as transformative: 'We were solving real horticultural problems rather than following a cookbook recipe.'",
        "Connected programmatic conditional statements directly to scientific decision trees and classification accuracy matrices. Mentored peers on data verification.",
        "Developed a balanced, responsible AI stance: recognizes immense productivity benefits for data parsing while advocating strict human verification of scientific claims.",
        "Demonstrated mastery of data cleaning; explained why missing sensor values must be systematically imputed or filtered rather than arbitrarily zeroed.",
        "Gained profound confidence in scientific argumentation using empirical data visualizations. Expressed enthusiasm for future computational biology studies.",
        "Highlighted the collaborative community (P5) as vital for belonging: felt respected and valued during reciprocal critique circles of AI outputs.",
        "Clearly distinguished supervised machine learning from rule-based programming; explained how training sample imbalances lead to classification biases in plants.",
        "Appreciated the scaffolded progression from visual widgets to Python notebooks. Advised expanding the curriculum to include local environmental sensor monitoring."
    ]

    interview_records = []
    for idx, pid in enumerate(sample_ids):
        demo_row = df_pre[df_pre["Participant_ID"] == pid].iloc[0]
        pre_row = df_pre[df_pre["Participant_ID"] == pid].iloc[0]
        post_row = df_post[df_post["Participant_ID"] == pid].iloc[0]

        interview_records.append({
            "Participant_ID": pid,
            "Grade": demo_row["Grade"],
            "Gender": demo_row["Gender"],
            "Programming_Experience": demo_row["Programming_Experience"],
            "Home_Language": demo_row["Primary_Home_Language"],
            "Pre_CT": pre_row["CT_Total"],
            "Post_CT": post_row["CT_Total"],
            "Pre_DSL": pre_row["DSL_Total"],
            "Post_DSL": post_row["DSL_Total"],
            "Pre_SE": round(pre_row["Self_Efficacy_Mean"], 2),
            "Post_SE": round(post_row["Self_Efficacy_Mean"], 2),
            "Pre_Interview_Summary": pre_narratives[idx],
            "Post_Interview_Summary": post_narratives[idx]
        })

    qual_df = pd.DataFrame(interview_records)
    return qual_df


# ==============================================================================
# 7. PARTICIPANT CHARACTERISTICS TABLE (TABLE 1)
# ==============================================================================

def create_participant_characteristics_table(df_demo: pd.DataFrame) -> pd.DataFrame:
    """
    Generate publication-ready Table 1 summarizing participant demographic characteristics (N=150).
    """
    total_n = len(df_demo)
    rows = []

    def add_category(var_name, series):
        counts = series.value_counts()
        for cat, cnt in counts.items():
            pct = (cnt / total_n) * 100
            rows.append({
                "Demographic Characteristic": f"{var_name}: {cat}",
                "Category / Level": cat,
                "Frequency (n)": cnt,
                "Percentage (%)": f"{pct:.1f}%",
                "Summary Metric": f"n = {cnt} ({pct:.1f}%)"
            })

    add_category("Grade Level", df_demo["Grade"])
    add_category("Gender", df_demo["Gender"])
    add_category("Primary Home Language", df_demo["Primary_Home_Language"])
    add_category("Multilingual Background", df_demo["Multilingual_Background"])
    add_category("Programming Experience", df_demo["Programming_Experience"])
    add_category("Previous AI Tool Usage", df_demo["Previous_AI_Tool_Usage"])

    table1_df = pd.DataFrame(rows)
    return table1_df


# ==============================================================================
# 8. CURRICULUM COMPARISON TABLE (TABLE 2)
# ==============================================================================

def create_curriculum_comparison_table() -> pd.DataFrame:
    """
    Generate publication-ready Table 2: Initial versus AI-Integrated Curriculum Comparison.
    """
    return pd.DataFrame(CONVENTIONAL_VS_AI_CURRICULUM)
